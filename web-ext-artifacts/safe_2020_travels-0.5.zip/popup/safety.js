import { getLatLon } from '../utils'


const form = document.querySelector('form');
console.log(form)

const handleSubmit = (ev) => {
  ev.preventDefault()
  const searchCity = document.querySelector('#search-location').value
  console.log(searchCity)
  //const data = getLatLon(searchCity)
  //console.log(data)
}

form.addEventListener("submit", handleSubmit)







/*const handleMessage = (request, sender, sendResponse) => {
  console.log('received msg in popup')
  if (request.command === 'get location data') {
    sendResponse({
      response: `Received request to ${request.command}`
    })
  }
  const messageDetails = {
    request: request,
    sender: sender,
  }
  console.log(messageDetails)
  sendResponse({
    response: 'received'
  })
}


const getLocationData = async () => {
  const dataRequest = await browser.tabs.sendMessage(
    {
      command: 'get location data'
    }
  )
  console.log(dataRequest)
}

browser.runtime.onMessage.addListener(handleMessage)
console.log('popup script: logged')*/

