export const covidDataAPIKey = 'c6210775d3cb47ddb082ac39f49662b1'
export const openCageAPIKey = '1d6f9911245e4ed38c4b5e6bd3d3ef8c'
